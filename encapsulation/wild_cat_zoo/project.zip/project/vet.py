from project import Worker


class Vet(Worker):
    pass