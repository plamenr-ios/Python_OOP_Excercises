from project import Worker


class Caretaker(Worker):
    pass