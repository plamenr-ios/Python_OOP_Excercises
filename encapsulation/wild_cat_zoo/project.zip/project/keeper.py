from project import Worker


class Keeper(Worker):
    pass