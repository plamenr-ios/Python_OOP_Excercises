from project import HotBeverage


class Tea(HotBeverage):
    pass