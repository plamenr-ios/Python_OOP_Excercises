from project import Beverage


class HotBeverage(Beverage):
    pass
