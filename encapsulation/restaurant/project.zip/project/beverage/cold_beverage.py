from project import Beverage


class ColdBeverage(Beverage):
    pass
