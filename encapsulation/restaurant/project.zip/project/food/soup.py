from project import Starter


class Soup(Starter):
    pass