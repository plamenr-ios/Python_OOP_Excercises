from project import Food


class MainDish(Food):
    pass